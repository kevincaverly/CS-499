package com.example.weightlossapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "WeightLossApp.db";
    private static final int DATABASE_VERSION = 1;

    // Users table
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USER_ID = "id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    // Weight entries table
    private static final String TABLE_WEIGHT_ENTRIES = "weight_entries";
    public static final String COLUMN_ENTRY_ID = "_id";
    private static final String COLUMN_USER_ID_FK = "user_id";
    public static final String COLUMN_WEIGHT = "weight";
    public static final String COLUMN_DATE = "date";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USERNAME + " TEXT UNIQUE NOT NULL, " +
                COLUMN_PASSWORD + " TEXT NOT NULL)";
        db.execSQL(createUsersTable);

        // Create weight entries table
        String createWeightEntriesTable = "CREATE TABLE " + TABLE_WEIGHT_ENTRIES + " (" +
                COLUMN_ENTRY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USER_ID_FK + " INTEGER NOT NULL, " +
                COLUMN_WEIGHT + " REAL NOT NULL, " +
                COLUMN_DATE + " TEXT NOT NULL, " +
                "FOREIGN KEY (" + COLUMN_USER_ID_FK + ") REFERENCES " + 
                TABLE_USERS + "(" + COLUMN_USER_ID + "))";
        db.execSQL(createWeightEntriesTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHT_ENTRIES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // Add a method to hash passwords securely
    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if(hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    // Improved addUser: returns 1 for success, -1 for error, -2 if user exists
    public int addUser(String username, String password) {
        username = username.trim();
        password = password.trim();
        if (userExists(username)) return -2; // Username exists
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, hashPassword(password));
        try {
            long result = db.insert(TABLE_USERS, null, values);
            return result == -1 ? -1 : 1; // -1: error, 1: success
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        } finally {
            db.close();
        }
    }

    // Check if a user exists by username
    public boolean userExists(String username) {
        username = username.trim();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query(TABLE_USERS, new String[]{COLUMN_USER_ID},
                    COLUMN_USERNAME + " = ?", new String[]{username},
                    null, null, null);
            boolean exists = cursor.getCount() > 0;
            return exists;
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
    }

    // Improved checkUser: hashes password before checking
    public boolean checkUser(String username, String password) {
        username = username.trim();
        password = password.trim();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try {
            String hashed = hashPassword(password);
            cursor = db.query(TABLE_USERS, new String[]{COLUMN_USER_ID},
                    COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?",
                    new String[]{username, hashed}, null, null, null);
            boolean valid = cursor.getCount() > 0;
            return valid;
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
    }

    // Development-only: clear all users from the users table
    public void clearUsersTable() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_USERS, null, null);
        db.close();
    }

    // Get user ID by username
    public int getUserId(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query(TABLE_USERS, new String[]{COLUMN_USER_ID},
                    COLUMN_USERNAME + " = ?", new String[]{username},
                    null, null, null);
            int userId = -1;
            if (cursor.moveToFirst()) {
                userId = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_USER_ID));
            }
            return userId;
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
    }

    // Improved addWeightEntry: closes db, returns true/false
    public boolean addWeightEntry(int userId, double weight, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_ID_FK, userId);
        values.put(COLUMN_WEIGHT, weight);
        values.put(COLUMN_DATE, date);
        try {
            long result = db.insert(TABLE_WEIGHT_ENTRIES, null, values);
            return result != -1;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            db.close();
        }
    }

    // Improved getWeightEntries: caller must close cursor
    public Cursor getWeightEntries(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_WEIGHT_ENTRIES, new String[]{COLUMN_ENTRY_ID, COLUMN_WEIGHT, COLUMN_DATE},
                COLUMN_USER_ID_FK + " = ?", new String[]{String.valueOf(userId)},
                null, null, COLUMN_DATE + " DESC");
    }

    // Improved updateWeightEntry: closes db, returns true/false
    public boolean updateWeightEntry(int entryId, double newWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WEIGHT, newWeight);
        try {
            int rowsAffected = db.update(TABLE_WEIGHT_ENTRIES, values,
                    COLUMN_ENTRY_ID + " = ?", new String[]{String.valueOf(entryId)});
            return rowsAffected > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            db.close();
        }
    }

    // Improved deleteWeightEntry: closes db, returns true/false
    public boolean deleteWeightEntry(int entryId) {
        SQLiteDatabase db = this.getWritableDatabase();
        try {
            int rowsAffected = db.delete(TABLE_WEIGHT_ENTRIES,
                    COLUMN_ENTRY_ID + " = ?", new String[]{String.valueOf(entryId)});
            return rowsAffected > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            db.close();
        }
    }
} 