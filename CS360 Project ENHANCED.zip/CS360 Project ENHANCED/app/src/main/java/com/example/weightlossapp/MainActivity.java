package com.example.weightlossapp;

import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {
    private TextView welcomeTextView;
    private EditText weightEditText;
    private Button addButton;
    private Button signOutButton;
    private GridView weightGridView;
    private DatabaseHelper databaseHelper;
    private SimpleCursorAdapter adapter;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = getIntent().getStringExtra("username");
        databaseHelper = new DatabaseHelper(this);

        welcomeTextView = findViewById(R.id.welcomeTextView);
        weightEditText = findViewById(R.id.weightEditText);
        addButton = findViewById(R.id.addButton);
        weightGridView = findViewById(R.id.weightGridView);
        signOutButton = findViewById(R.id.signOutButton);

        welcomeTextView.setText("Welcome, " + username + "!");

        setupGridView();
        setupAddButton();
        setupGridViewItemClick();
        setupSignOutButton();
    }

    private void setupGridView() {
        Cursor cursor = databaseHelper.getWeightEntries(getUserId());
        String[] fromColumns = {DatabaseHelper.COLUMN_WEIGHT, DatabaseHelper.COLUMN_DATE};
        int[] toViews = {android.R.id.text1, android.R.id.text2};

        adapter = new SimpleCursorAdapter(
                this,
                android.R.layout.simple_list_item_2,
                cursor,
                fromColumns,
                toViews,
                0
        );

        weightGridView.setAdapter(adapter);
    }

    private void setupAddButton() {
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String weightStr = weightEditText.getText().toString();
                if (weightStr.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter a weight", Toast.LENGTH_SHORT).show();
                    return;
                }

                double weight = Double.parseDouble(weightStr);
                String date = java.text.DateFormat.getDateTimeInstance().format(new java.util.Date());

                if (databaseHelper.addWeightEntry(getUserId(), weight, date)) {
                    Toast.makeText(MainActivity.this, "Weight entry added", Toast.LENGTH_SHORT).show();
                    weightEditText.setText("");
                    refreshGridView();
                } else {
                    Toast.makeText(MainActivity.this, "Failed to add weight entry", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void setupGridViewItemClick() {
        weightGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                showEditDeleteDialog(id);
            }
        });
    }

    private void showEditDeleteDialog(final long entryId) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Options")
                .setItems(new String[]{"Edit", "Delete"}, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) {
                            showEditDialog(entryId);
                        } else {
                            showDeleteConfirmationDialog(entryId);
                        }
                    }
                });
        builder.show();
    }

    private void showEditDialog(final long entryId) {
        final EditText input = new EditText(this);
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);

        new AlertDialog.Builder(this)
                .setTitle("Edit Weight")
                .setView(input)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String newWeightStr = input.getText().toString();
                        if (!newWeightStr.isEmpty()) {
                            double newWeight = Double.parseDouble(newWeightStr);
                            if (databaseHelper.updateWeightEntry((int) entryId, newWeight)) {
                                Toast.makeText(MainActivity.this, "Weight updated", Toast.LENGTH_SHORT).show();
                                refreshGridView();
                            }
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showDeleteConfirmationDialog(final long entryId) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Entry")
                .setMessage("Are you sure you want to delete this entry?")
                .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (databaseHelper.deleteWeightEntry((int) entryId)) {
                            Toast.makeText(MainActivity.this, "Entry deleted", Toast.LENGTH_SHORT).show();
                            refreshGridView();
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void refreshGridView() {
        Cursor newCursor = databaseHelper.getWeightEntries(getUserId());
        adapter.changeCursor(newCursor);
    }

    private int getUserId() {
        // Use the improved method to get the actual user ID from the database
        return databaseHelper.getUserId(username);
    }

    private void setupSignOutButton() {
        signOutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            }
        });
    }
} 